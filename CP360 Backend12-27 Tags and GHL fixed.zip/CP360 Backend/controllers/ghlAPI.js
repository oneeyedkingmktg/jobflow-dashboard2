// ============================================================================
// controllers/ghlAPI.js (v4.3) – Multi-Company GHL Integration (LeadConnector v2)
// Changes:
// - Fixed applyStatusTags to properly decrypt API key before using ghlClient
// - Fixed tag application to work for both new AND existing contacts
// ============================================================================

const fetch = require("node-fetch");
const db = require("../config/database");
const CryptoJS = require("crypto-js");

// Load encryption key (same key used in companies.js)
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || "change-this-encryption-key";

// ----------------------------------------------------------------------------
// DECRYPT COMPANY API KEY
// ----------------------------------------------------------------------------
function decryptApiKey(encryptedKey) {
  if (!encryptedKey) return null;

  try {
    const bytes = CryptoJS.AES.decrypt(encryptedKey, ENCRYPTION_KEY);
    const decrypted = bytes.toString(CryptoJS.enc.Utf8);

    if (decrypted && decrypted.trim().length >= 20) {
      return decrypted.trim();
    }

    return null;
  } catch (err) {
    return null;
  }
}

// ----------------------------------------------------------------------------
// RESOLVE API KEY (supports raw OR encrypted during stabilization)
// ----------------------------------------------------------------------------
function resolveApiKey(storedValue) {
  if (!storedValue) return null;

  // Try decrypting first (normal expected state)
  const decrypted = decryptApiKey(storedValue);

  if (decrypted && typeof decrypted === "string" && decrypted.trim().length >= 20) {
    return decrypted.trim();
  }

  // If decrypt fails, assume it's a raw key stored directly
  if (typeof storedValue === "string" && storedValue.trim().length >= 20) {
    return storedValue.trim();
  }

  return null;
}

// ✅ LeadConnector v2 base URL
const GHL_BASE_URL = "https://services.leadconnectorhq.com";
// ✅ Required header for LC API
const GHL_API_VERSION = "2021-07-28";

// ----------------------------------------------------------------------------
// PHONE NORMALIZATION
// ----------------------------------------------------------------------------
function normalizePhone(phone) {
  if (!phone) return null;
  const digits = String(phone).replace(/\D/g, "");

  if (!digits) return null;
  if (digits.length === 10) return `+1${digits}`;
  if (digits.length === 11 && digits.startsWith("1")) return `+${digits}`;
  if (!digits.startsWith("+")) return `+${digits}`;
  return digits;
}

// ----------------------------------------------------------------------------
// LOW-LEVEL GHL REQUEST WRAPPER
// ----------------------------------------------------------------------------
async function ghlRequest(company, endpoint, options = {}) {
  const encryptedApiKey = company.ghl_api_key;
  const locationId = company.ghl_location_id;

  if (!encryptedApiKey) throw new Error("Company missing encrypted GHL API key");
  if (!locationId) throw new Error("Company missing GHL location ID");

  const apiKey = resolveApiKey(encryptedApiKey);

  // ✅ Fail loudly if decrypt is broken
  if (!apiKey || typeof apiKey !== "string" || apiKey.trim().length < 20) {
    throw new Error(
      "GHL API key decrypt failed (check ENCRYPTION_KEY matches the key used to encrypt stored API keys)"
    );
  }

  const url = new URL(`${GHL_BASE_URL}${endpoint}`);

  const params = options.params || {};

  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") {
      url.searchParams.append(k, v);
    }
  });

  const fetchOptions = {
    method: options.method || "GET",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      Version: String(GHL_API_VERSION).trim(),
      "Content-Type": "application/json",
      Accept: "application/json"
    },
  };

  if (options.body) fetchOptions.body = JSON.stringify(options.body);

  console.log("GHL REQUEST DEBUG", {
    url: url.toString(),
    method: fetchOptions.method,
  });

  const res = await fetch(url.toString(), fetchOptions);
  const raw = await res.text();

  let data;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch {
    data = raw;
  }

  if (!res.ok) {
    const error = new Error(`GHL API error ${res.status}`);
    error.status = res.status;
    error.response = data;
    throw error;
  }

  return data;
}

// ----------------------------------------------------------------------------
// STATUS MAP
// ----------------------------------------------------------------------------
const STATUS_TAGS = {
  lead: "status - lead",
  appointment_set: "status - appointment set",
  sold: "status - sold",
  not_sold: "status - not sold",
  completed: "status - complete",
};

// ----------------------------------------------------------------------------
// APPLY STATUS TAGS (FIXED - NOW USES ghlRequest INSTEAD OF ghlClient)
// ----------------------------------------------------------------------------
async function applyStatusTags(contactId, newStatusTag, company) {
  if (!contactId || !newStatusTag) return;

  console.log("🏷️  [GHL TAG] Applying tag:", newStatusTag, "to contact:", contactId);

  try {
    await ghlRequest(company, `/contacts/${contactId}/tags`, {
      method: "POST",
      body: {
        tags: [newStatusTag],
      },
    });
    console.log("✅ [GHL TAG] Successfully applied:", newStatusTag);
  } catch (err) {
    console.error("❌ [GHL TAG] Failed to apply tag:", err.message);
    console.error("   Status:", err.status);
    console.error("   Response:", err.response);
  }
}

// ----------------------------------------------------------------------------
// UPSERT CONTACT FROM LEAD (FIXED - TAGS NOW APPLIED IN ALL CASES)
// ----------------------------------------------------------------------------
async function upsertContactFromLead(lead, company) {
  const phone = normalizePhone(lead.phone);
  const email = lead.email;

  const payload = {
    firstName: lead.first_name || "",
    lastName: lead.last_name || "",
    email: email || "",
    phone: phone || "",
    source: "JobFlow",
  };

  let contact;
  let contactId;

  try {
    // Try creating new contact
    const response = await ghlRequest(company, "/contacts/", {
      method: "POST",
      body: {
        locationId: company.ghl_location_id,
        ...payload
      },
    });
    
    contact = response.contact || response;
    contactId = contact.id;
    console.log("✅ [CONTACT] Created new contact:", contactId);

  } catch (err) {
    // Check if duplicate contact
    const meta = err?.response?.meta || err?.meta;

    if (meta?.contactId) {
      // Contact already exists - update it
      contactId = meta.contactId;
      console.log("ℹ️  [CONTACT] Already exists, updating:", contactId);
      
      const updateResponse = await ghlRequest(
        company,
        `/contacts/${contactId}`,
        {
          method: "PUT",
          body: payload,
        }
      );
      
      contact = updateResponse.contact || updateResponse;
    } else {
      throw err;
    }
  }

  // ------------------------------------------------------------
  // APPLY STATUS TAG (WORKS FOR BOTH NEW AND EXISTING CONTACTS)
  // ------------------------------------------------------------
  if (contactId) {
    const status = String(lead.status || "").trim().toLowerCase();
    console.log("🔍 [STATUS] Lead status:", status);

    const tagToAssign = STATUS_TAGS[status] || null;

    if (tagToAssign) {
      await applyStatusTags(contactId, tagToAssign, company);
    } else {
      console.log("⚠️  [STATUS] No tag mapping for status:", status);
    }
  }

  return contact;
}

// ----------------------------------------------------------------------------
// MODULE EXPORTS
// ----------------------------------------------------------------------------
module.exports = {
  syncLeadToGHL: async function (lead, company) {
    try {
      const contact = await upsertContactFromLead(lead, company);

      await db.query(
        `UPDATE leads
         SET ghl_sync_status = 'success',
             ghl_last_synced = NOW()
         WHERE id = $1`,
        [lead.id]
      );

      return contact;
    } catch (err) {
      console.error("❌ [SYNC ERROR]", err.message);
      await db.query(
        `UPDATE leads
         SET ghl_sync_status = 'error',
             ghl_last_synced = NOW()
         WHERE id = $1`,
        [lead.id]
      );
      throw err;
    }
  },

  searchGHLContactByPhone: async function (phone, company) {
    const normalized = normalizePhone(phone);
    if (!normalized) return null;

    return await ghlRequest(company, "/contacts/", {
      method: "GET",
      params: { query: normalized },
    });
  },

  fetchGHLContact: async function (contactId, company) {
    if (!contactId || typeof contactId !== "string" || !contactId.trim()) {
      return null;
    }

    return await ghlRequest(company, `/contacts/${contactId.trim()}`, {
      method: "GET",
    });
  },
};