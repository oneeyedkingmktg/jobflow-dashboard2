// ============================================================================
// File: sync/dbToGhlSync.js
// Version: v1.3.0
// Purpose:
// - Thin wrapper that delegates all GHL logic to controllers/ghlAPI.js
// - Tag handling, contact creation, status mapping all live there
// ============================================================================

const {
  syncLeadToGHL,
  syncLeadCalendarEvent,
} = require("../controllers/ghlAPI");


async function syncLeadToGhl({ lead, previousLead = null, company }) {
  if (!lead || !company) return;

  try {
    // 1️⃣ Sync contact + tags
    await syncLeadToGHL(lead, company);

    // 2️⃣ Sync calendar event (Phase 1 – exact dates only)
    const result = await syncLeadCalendarEvent(lead, company);

    if (result?.calendarEventId) {
      if (result.type === "appointment") {
        await require("../config/database").query(
          `UPDATE leads
           SET appointment_calendar_event_id = $1
           WHERE id = $2`,
          [result.calendarEventId, lead.id]
        );
      }

      if (result.type === "install") {
        await require("../config/database").query(
          `UPDATE leads
           SET install_calendar_event_id = $1
           WHERE id = $2`,
          [result.calendarEventId, lead.id]
        );
      }
    }
  } catch (error) {
    console.error("GHL sync failed:", error.message);
    throw error;
  }
}


module.exports = {
  syncLeadToGhl,
};
