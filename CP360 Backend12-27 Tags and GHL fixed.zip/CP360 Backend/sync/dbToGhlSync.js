// ============================================================================
// File: sync/dbToGhlSync.js
// Version: v1.3.0
// Purpose:
// - Thin wrapper that delegates all GHL logic to controllers/ghlAPI.js
// - Tag handling, contact creation, status mapping all live there
// ============================================================================

const { syncLeadToGHL } = require("../controllers/ghlAPI");

async function syncLeadToGhl({ lead, previousLead = null, company }) {
  if (!lead || !company) return;

  try {
    await syncLeadToGHL(lead, company);
  } catch (error) {
    console.error("GHL sync failed:", error.message);
    throw error;
  }
}

module.exports = {
  syncLeadToGhl,
};
